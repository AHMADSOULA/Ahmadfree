package com.ahmadfre.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.setContent
import androidx.core.content.ContextCompat

class SplashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var proceed by remember { mutableStateOf(false) }
            MaterialTheme {
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier.fillMaxSize(),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                ) {
                    Text("تابع المطور على الفيسبوك", color = Color.Blue)
                    Text("أحمد صولح", color = Color.Blue)
                    Text("لن يعمل التطبيق حتى تتابع المطور", color = Color.Red)
                    Button(onClick = {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/ahmd.swlh.553992")))
                        proceed = true
                    }) {
                        Text("زيارة الصفحة")
                    }
                    if (proceed) {
                        LaunchedEffect(Unit) {
                            startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                            finish()
                        }
                    }
                }
            }
        }
    }
}
